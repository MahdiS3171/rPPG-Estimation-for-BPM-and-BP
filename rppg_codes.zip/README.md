# rPPG Lab – نسخه تمیز پروژه ضربان قلب و فشارخون

این نسخه، کدهای قبلی پروژه را به یک ساختار تمیزتر و قابل ادامه تبدیل می‌کند. هدف فعلی این repo این است که اول **rPPG و ضربان قلب** را با مسیر قابل‌دفاع و subject-wise benchmark جلو ببریم و بعد، با احتیاط علمی، وارد **فشارخون** شویم.

## تصمیم‌های مهم این نسخه

1. مسیر اصلی ضربان قلب **waveform-first** است، نه فقط HR regression. یعنی مدل اول waveform شبیه PPG/rPPG می‌سازد و بعد HR از روی PSD/peak استخراج می‌شود.
2. روش‌های کلاسیک مثل `POS_WIN`, `CHROM_WIN`, `LGI`, `OMIT`, `PBV` به عنوان baseline و prior نگه داشته شده‌اند.
3. split پیش‌فرض برای ارزیابی باید subject-wise باشد. window split برای گزارش علمی ممنوع است، چون leakage می‌دهد.
4. فشارخون فعلا فقط در حد baseline feature-level و scaffold نگه داشته شده است. claim جدی BP باید بعد از pilot data و reference درست انجام شود.

## ساختار فایل‌ها

```text
rppg_project_clean/
  rppg_lab/
    classical.py      # روش‌های کلاسیک rPPG
    roi.py            # استخراج ROI چندناحیه‌ای با MediaPipe
    signals.py        # فیلتر، HR، SNR، PTT/phase، PWA features
    datasets.py       # UBFC و datasetهای آینده
    models.py         # WaveformNet، MultiROIWaveformNet، BPFeatureMLP
    losses.py         # waveform lossها
    metrics.py        # MAE/RMSE/Bland-Altman/AAMI sanity
  scripts/
    extract_rppg_from_video.py
    benchmark_classical_ubfc.py
    train_waveform_ubfc.py
    train_bp_baseline.py
  docs/
    ARCHITECTURE.md
    TODO.md
  requirements.txt
  pyproject.toml
```

## نصب سریع

```bash
cd rppg_project_clean
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
# source .venv/bin/activate

pip install -r requirements.txt
pip install -e .
```

> اگر MediaPipe روی نسخه پایتونت نصب نشد، از Python 3.10 یا 3.11 استفاده کن. برای شروع بهتر است وارد درگیری Python 3.13 نشویم.

## تست یک ویدیو با روش کلاسیک

```bash
python scripts/extract_rppg_from_video.py path/to/video.mp4 --method POS_WIN --roi face --fs 30
```

خروجی HR، confidence و SNR می‌دهد.

## benchmark کلاسیک روی UBFC

ساختار UBFC باید چیزی شبیه این باشد:

```text
UBFCData/
  subject1/
    vid.avi
    ground_truth.txt
  subject2/
    vid.avi
    ground_truth.txt
```

اجرا:

```bash
python scripts/benchmark_classical_ubfc.py --ubfc-root UBFCData --method POS_WIN --roi face --out outputs/classical_pos_ubfc.csv
```

## آموزش WaveformNet روی UBFC

```bash
python scripts/train_waveform_ubfc.py --ubfc-root UBFCData --epochs 30 --out checkpoints/waveformnet_ubfc.pt
```

به صورت پیش‌فرض ورودی مدل این‌هاست:

```text
RGB + POS_WIN + CHROM_WIN + LGI + OMIT + PBV
```

اگر خواستی فقط RGB را تست کنی:

```bash
python scripts/train_waveform_ubfc.py --ubfc-root UBFCData --no-priors
```

## مسیر فشارخون

در این repo فعلا `BPFeatureMLP` داریم، ولی این فقط برای وقتی است که دیتای خودمان یا دیتاست BP قابل‌قبول داشته باشیم. ورودی درست BP باید در آینده شامل موارد زیر باشد:

- rPPG صورت
- rPPG دست/انگشت/کف دست
- PTT/phase delay
- PWA features
- HR/HRV
- مشخصات فردی
- cuff calibration
- quality/confidence

تا قبل از اینکه rPPG پایدار و PTT قابل‌اندازه‌گیری داشته باشیم، نباید claim فشارخون بدهیم.

## تفاوت با کد قبلی

کد قبلی ایده‌های خوبی داشت، ولی چند مشکل داشت:

- بعضی فایل‌ها در README_V2 معرفی شده بودند اما در کد واقعی کامل تعریف نشده بودند.
- بخش BP هنوز runnable و علمی نبود.
- کدها، خروجی‌ها، cacheها و checkpointها قاطی بودند.
- مسیر training/evaluation جدا و تمیز نبود.

این نسخه از صفر تمیز شده تا از همین‌جا ادامه بدهیم.
