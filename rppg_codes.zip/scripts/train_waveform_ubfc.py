#!/usr/bin/env python
"""Train waveform-first rPPG model on UBFC with subject-wise split."""
from __future__ import annotations

import argparse
from pathlib import Path
import sys
import numpy as np
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

sys.path.append(str(Path(__file__).resolve().parents[1]))

from rppg_lab.datasets import find_ubfc_subjects, subject_split, UBFCRPPGDataset
from rppg_lab.classical import DEFAULT_PRIORS
from rppg_lab.models import WaveformNet
from rppg_lab.losses import rppg_training_loss
from rppg_lab.metrics import waveform_corr, waveform_corr_aligned, regression_metrics
from rppg_lab.signals import estimate_hr_welch


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--ubfc-root", required=True)
    ap.add_argument("--cache-dir", default="cache_roi")
    ap.add_argument("--out", default="checkpoints/waveformnet_ubfc.pt")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--fs", type=float, default=30.0)
    ap.add_argument("--win-sec", type=float, default=8.0)
    ap.add_argument("--stride-sec", type=float, default=1.0)
    ap.add_argument("--roi", default="face")
    ap.add_argument("--no-priors", action="store_true")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    subjects = find_ubfc_subjects(args.ubfc_root)
    train_subj, val_subj = subject_split(subjects, val_fraction=0.2, seed=args.seed)
    priors = [] if args.no_priors else list(DEFAULT_PRIORS)
    print(f"Using priors: {priors}")
    train_ds = UBFCRPPGDataset(train_subj, fs_target=args.fs, win_sec=args.win_sec, stride_sec=args.stride_sec, roi=args.roi, cache_dir=args.cache_dir, prior_methods=priors)
    val_ds = UBFCRPPGDataset(val_subj, fs_target=args.fs, win_sec=args.win_sec, stride_sec=args.stride_sec, roi=args.roi, cache_dir=args.cache_dir, prior_methods=priors)
    train_loader = DataLoader(train_ds, batch_size=args.batch_size, shuffle=True, num_workers=0)
    val_loader = DataLoader(val_ds, batch_size=args.batch_size, shuffle=False, num_workers=0)
    sample = train_ds[0]
    in_ch = int(sample["x"].shape[0])
    print(f"Input channels: {in_ch}")
    print(f"Train samples: {len(train_ds)} | Val samples: {len(val_ds)}")
    model = WaveformNet(in_channels=in_ch).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-4)
    best = np.inf
    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    for epoch in range(1, args.epochs + 1):
        model.train()
        tr = []
        for batch in tqdm(train_loader, desc=f"epoch {epoch}/{args.epochs}"):
            x = batch["x"].to(device)
            y = batch["y_ppg"].to(device)
            y_hr = batch["y_hr"].to(device)

            pred = model(x)

            loss = rppg_training_loss(
                pred=pred,
                target=y,
                hr_bpm=y_hr,
                fs=args.fs,
                epoch=epoch,
                total_epochs=args.epochs,
            )
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            tr.append(float(loss.item()))

        model.eval()
        cors, cors_aligned, gt_hr, pr_hr = [], [], [], []
        with torch.no_grad():
            for batch in val_loader:
                x = batch["x"].to(device)
                y = batch["y_ppg"].numpy()
                pred = model(x).cpu().numpy()
                for i in range(pred.shape[0]):
                    cors.append(waveform_corr(y[i], pred[i]))
                    cors_aligned.append(waveform_corr_aligned(y[i], pred[i], max_lag=int(0.5 * args.fs)))
                    pr_hr.append(estimate_hr_welch(pred[i], args.fs).hr_bpm)
                    gt_hr.append(float(batch["y_hr"][i]))
        hr_m = regression_metrics(gt_hr, pr_hr)
        val_score = hr_m.mae
        print(
            f"epoch={epoch} "
            f"train_loss={np.mean(tr):.4f} "
            f"val_wave_corr={np.nanmean(cors):.3f} "
            f"val_wave_corr_aligned={np.nanmean(cors_aligned):.3f} "
            f"val_HR_MAE={hr_m.mae:.3f}"
        )
        if val_score < best:
            best = val_score
            torch.save({
                "model_state": model.state_dict(),
                "model": "WaveformNet",
                "in_channels": in_ch,
                "fs": args.fs,
                "win_sec": args.win_sec,
                "priors": [] if args.no_priors else "DEFAULT_PRIORS",
                "train_subjects": [s.subject_id for s in train_subj],
                "val_subjects": [s.subject_id for s in val_subj],
                "best_val_hr_mae": best,
            }, out_path)
            print("saved best:", out_path)


if __name__ == "__main__":
    main()
