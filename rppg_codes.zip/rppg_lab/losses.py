"""Loss functions for waveform-first rPPG training."""
from __future__ import annotations

import torch
import torch.nn.functional as F

EPS = 1e-8


def negative_pearson_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """1 - Pearson correlation averaged over batch.

    pred and target: (B, L)
    """
    pred = pred - pred.mean(dim=-1, keepdim=True)
    target = target - target.mean(dim=-1, keepdim=True)
    num = (pred * target).sum(dim=-1)
    den = torch.sqrt((pred.pow(2).sum(dim=-1) + EPS) * (target.pow(2).sum(dim=-1) + EPS))
    corr = num / den
    return (1.0 - corr).mean()


def spectral_mse_loss(pred: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
    """MSE between normalized magnitude spectra."""
    P = torch.fft.rfft(pred, dim=-1).abs()
    T = torch.fft.rfft(target, dim=-1).abs()
    P = P / (P.sum(dim=-1, keepdim=True) + EPS)
    T = T / (T.sum(dim=-1, keepdim=True) + EPS)
    return F.mse_loss(P, T)


def smoothness_loss(pred: torch.Tensor) -> torch.Tensor:
    """Small penalty on sample-to-sample roughness."""
    return (pred[..., 1:] - pred[..., :-1]).pow(2).mean()


def waveform_combo_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    pearson_weight: float = 1.0,
    spectral_weight: float = 0.2,
    mse_weight: float = 0.1,
    smooth_weight: float = 0.01,
) -> torch.Tensor:
    return (
        pearson_weight * negative_pearson_loss(pred, target)
        + spectral_weight * spectral_mse_loss(pred, target)
        + mse_weight * F.mse_loss(pred, target)
        + smooth_weight * smoothness_loss(pred)
    )
    
def time_shifted_negative_pearson_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    max_lag: int = 15,
) -> torch.Tensor:
    """
    Time-shift tolerant Pearson loss.

    This is important because facial rPPG and contact finger PPG may have
    a small physiological delay. A pointwise zero-lag correlation can unfairly
    penalize a correct pulse waveform.
    """
    losses = []

    for lag in range(-max_lag, max_lag + 1):
        if lag < 0:
            p = pred[..., :lag]
            t = target[..., -lag:]
        elif lag > 0:
            p = pred[..., lag:]
            t = target[..., :-lag]
        else:
            p = pred
            t = target

        if p.shape[-1] < 8:
            continue

        p = p - p.mean(dim=-1, keepdim=True)
        t = t - t.mean(dim=-1, keepdim=True)

        num = (p * t).sum(dim=-1)
        den = torch.sqrt((p.pow(2).sum(dim=-1) + EPS) * (t.pow(2).sum(dim=-1) + EPS))
        corr = num / den
        losses.append(1.0 - corr)

    stacked = torch.stack(losses, dim=0)  # (num_lags, B)
    best_loss = stacked.min(dim=0).values
    return best_loss.mean()


def hr_label_distribution_loss(
    pred: torch.Tensor,
    hr_bpm: torch.Tensor,
    fs: float,
    fmin: float = 0.7,
    fmax: float = 3.5,
    sigma_bpm: float = 3.0,
) -> torch.Tensor:
    """
    Frequency-domain HR supervision.

    Builds a Gaussian target distribution centered at ground-truth HR and
    compares it with the normalized PSD of predicted waveform.
    """
    x = pred - pred.mean(dim=-1, keepdim=True)

    psd = torch.fft.rfft(x, dim=-1).abs().pow(2)
    freqs = torch.fft.rfftfreq(pred.shape[-1], d=1.0 / float(fs)).to(pred.device)

    band = (freqs >= fmin) & (freqs <= fmax)
    psd_b = psd[:, band]
    f_bpm = freqs[band] * 60.0

    log_probs = torch.log_softmax(psd_b, dim=-1)

    hr = hr_bpm.to(pred.device).float().view(-1, 1)
    sigma = float(sigma_bpm)

    target = torch.exp(-0.5 * ((f_bpm.view(1, -1) - hr) / sigma) ** 2)
    target = target / (target.sum(dim=-1, keepdim=True) + EPS)

    return -(target * log_probs).sum(dim=-1).mean()


def rppg_training_loss(
    pred: torch.Tensor,
    target: torch.Tensor,
    hr_bpm: torch.Tensor,
    fs: float,
    epoch: int,
    total_epochs: int,
    max_lag_sec: float = 0.5,
) -> torch.Tensor:
    """
    Dynamic time + frequency loss.

    Early epochs: more tolerant temporal/waveform learning.
    Later epochs: stronger frequency/HR supervision.
    """
    max_lag = int(round(max_lag_sec * fs))

    time_loss = time_shifted_negative_pearson_loss(pred, target, max_lag=max_lag)

    freq_loss = hr_label_distribution_loss(
        pred=pred,
        hr_bpm=hr_bpm,
        fs=fs,
        sigma_bpm=3.0,
    )

    smooth = smoothness_loss(pred)

    progress = float(epoch - 1) / max(1.0, float(total_epochs - 1))
    beta = 0.2 + 1.8 * progress

    return 0.3 * time_loss + beta * freq_loss + 0.005 * smooth
