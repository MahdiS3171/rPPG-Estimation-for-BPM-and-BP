"""PyTorch models for the cleaned rPPG/BP project.

The default scientific path is waveform-first: predict an rPPG/PPG waveform and
estimate HR from the waveform. Direct HR regression is kept only as a baseline.
"""
from __future__ import annotations

from typing import Dict, Optional
import torch
import torch.nn as nn
import torch.nn.functional as F


class ResidualBlock1D(nn.Module):
    def __init__(self, channels: int, kernel_size: int = 7, dilation: int = 1, dropout: float = 0.0):
        super().__init__()
        pad = dilation * (kernel_size - 1) // 2
        self.net = nn.Sequential(
            nn.Conv1d(channels, channels, kernel_size, padding=pad, dilation=dilation),
            nn.BatchNorm1d(channels),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout) if dropout > 0 else nn.Identity(),
            nn.Conv1d(channels, channels, kernel_size, padding=pad, dilation=dilation),
            nn.BatchNorm1d(channels),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return F.relu(x + self.net(x), inplace=True)


class TemporalEncoder1D(nn.Module):
    """Dilated residual temporal encoder for RGB/prior traces."""

    def __init__(self, in_channels: int, base_channels: int = 48, num_blocks: int = 6, dropout: float = 0.1):
        super().__init__()
        self.input = nn.Sequential(
            nn.Conv1d(in_channels, base_channels, kernel_size=7, padding=3),
            nn.BatchNorm1d(base_channels),
            nn.ReLU(inplace=True),
        )
        blocks = []
        for i in range(num_blocks):
            blocks.append(ResidualBlock1D(base_channels, kernel_size=7, dilation=2 ** (i % 4), dropout=dropout))
        self.blocks = nn.Sequential(*blocks)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.blocks(self.input(x))


class HR1DCNN(nn.Module):
    """Simple direct HR regression baseline.

    Input:  (B, C, L)
    Output: (B,)
    """

    def __init__(self, in_channels: int = 3):
        super().__init__()
        self.encoder = nn.Sequential(
            nn.Conv1d(in_channels, 32, 5, padding=2), nn.BatchNorm1d(32), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(32, 64, 5, padding=2), nn.BatchNorm1d(64), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(64, 128, 5, padding=2), nn.BatchNorm1d(128), nn.ReLU(), nn.MaxPool1d(2),
        )
        self.head = nn.Sequential(nn.Linear(128, 64), nn.ReLU(), nn.Linear(64, 1))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        z = self.encoder(x).mean(dim=-1)
        return self.head(z).squeeze(-1)


class WaveformNet(nn.Module):
    """Single-trace waveform model.

    Use in_channels=3 for RGB only, or in_channels=3+K when classic priors are
    concatenated as extra channels.
    """

    def __init__(self, in_channels: int = 3, base_channels: int = 48, num_blocks: int = 6, dropout: float = 0.1):
        super().__init__()
        self.encoder = TemporalEncoder1D(in_channels, base_channels, num_blocks, dropout)
        self.ppg_head = nn.Conv1d(base_channels, 1, kernel_size=7, padding=3)
        self.quality_head = nn.Sequential(
            nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Linear(base_channels, 1), nn.Sigmoid()
        )

    def forward(self, x: torch.Tensor, return_dict: bool = False):
        feat = self.encoder(x)
        ppg = self.ppg_head(feat).squeeze(1)
        quality = self.quality_head(feat).squeeze(-1)
        if return_dict:
            return {"ppg": ppg, "quality": quality, "features": feat}
        return ppg


class MultiROIWaveformNet(nn.Module):
    """Shared temporal encoder + learnable ROI attention.

    Input shape: (B, R, C, L), where R is number of ROIs and C is channels per
    ROI (RGB + optional classical priors). Optional external roi_quality has
    shape (B, R) and biases attention away from bad ROI traces.
    """

    def __init__(self, in_channels: int, base_channels: int = 48, num_blocks: int = 5, dropout: float = 0.1):
        super().__init__()
        self.shared = TemporalEncoder1D(in_channels, base_channels, num_blocks, dropout)
        self.attn_head = nn.Sequential(
            nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Linear(base_channels, 1)
        )
        self.ppg_head = nn.Conv1d(base_channels, 1, kernel_size=7, padding=3)
        self.quality_head = nn.Sequential(nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Linear(base_channels, 1), nn.Sigmoid())

    def forward(self, x: torch.Tensor, roi_quality: Optional[torch.Tensor] = None, return_dict: bool = False):
        b, r, c, l = x.shape
        flat = x.reshape(b * r, c, l)
        feat = self.shared(flat)  # (B*R, F, L)
        logits = self.attn_head(feat).reshape(b, r)
        if roi_quality is not None:
            logits = logits + torch.log(torch.clamp(roi_quality, min=1e-4))
        alpha = torch.softmax(logits, dim=1)  # (B, R)
        feat = feat.reshape(b, r, feat.shape[1], l)
        fused = (feat * alpha[:, :, None, None]).sum(dim=1)
        ppg = self.ppg_head(fused).squeeze(1)
        quality = self.quality_head(fused).squeeze(-1)
        if return_dict:
            return {"ppg": ppg, "quality": quality, "roi_attention": alpha, "features": fused}
        return ppg


class BPFeatureMLP(nn.Module):
    """First BP baseline for engineered features + metadata + cuff calibration.

    This is intentionally a feature-level baseline. Do not use it to claim BP from
    face video alone. It is for pilot data and sanity checks.
    """

    def __init__(self, in_features: int, hidden: int = 128, dropout: float = 0.15, out_dim: int = 2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_features, hidden), nn.BatchNorm1d(hidden), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden, hidden), nn.BatchNorm1d(hidden), nn.ReLU(), nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2), nn.ReLU(), nn.Linear(hidden // 2, out_dim),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class HealthMultiTaskNet(nn.Module):
    """Forward-compatible multi-task scaffold.

    Main supervised output should remain `ppg` until we have a clean BP dataset.
    BP heads are optional and should only be trained with subject-wise splits,
    calibration metadata, and proper reference measurements.
    """

    def __init__(self, in_channels: int = 3, base_channels: int = 48, num_blocks: int = 6, dropout: float = 0.1):
        super().__init__()
        self.backbone = WaveformNet(in_channels, base_channels, num_blocks, dropout)
        self.hr_head = nn.Sequential(nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Linear(base_channels, 64), nn.ReLU(), nn.Linear(64, 1))
        self.bp_head = nn.Sequential(nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Linear(base_channels, 64), nn.ReLU(), nn.Linear(64, 2))

    def forward(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        out = self.backbone(x, return_dict=True)
        feat = out["features"]
        return {
            "ppg": out["ppg"],
            "quality": out["quality"],
            "hr": self.hr_head(feat).squeeze(-1),
            "bp": self.bp_head(feat),
        }
